package Model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
public class eGames {

    static final Long serialVersionUID = 17L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idGame;
    
    @Column
    private String name;
    
    @Column
    private String tipoJuego;
    
    // ==================Cree la relació amb la classe Compite===================
    @OneToMany(mappedBy = "game")
    private Set<Compite> game = new HashSet<>();
    

    public eGames(String name, String tipoJuego){
        this.name = name;
        this.tipoJuego = tipoJuego;
    }
    
    public void afigCompeticio(Compite compite){
        game.add(compite);
    }
    
    @Override
    public String toString(){
        return "- " + this.idGame + " " + this.name + " es un juego de tipo " + this.tipoJuego;
    }
}
