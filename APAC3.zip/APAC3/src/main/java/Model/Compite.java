package Model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
public class Compite {
    
    static final Long serialVersionUID=17L;
    
    @EmbeddedId
    @GeneratedValue(strategy = GenerationType.IDENTITY) // L'hi diem que es auto-incremental.
    private TeamGamesId id = new TeamGamesId();
    
    @Column
    private int nJugadores;
    
    // Relacions
    @ManyToOne (cascade=CascadeType.PERSIST)
    @MapsId("idTeam")
    private eTeam team;
    
    // Relacions
    @ManyToOne (cascade=CascadeType.PERSIST)
    @MapsId("idGame")
    private eGames game;
    
    @Override
    public String toString(){
        return "· Id de la competició: " + this.id + "  Team: " + this.team.getNomTeam() + " Game: " + this.game.getName(); 
    }
    
}
