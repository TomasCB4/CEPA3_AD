package Model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="eTeam")
@Setter@Getter@ToString@NoArgsConstructor
public class eTeam {
    
    static final Long serialVersionUID=17L;
    
    @Id
    @Column
    private String nomTeam; // ID del eTeam
    
    @Column
    private int pressupost; // Columna de la tabla.
    
    // ===============Creem la relació amb la classe manager.===================
    @OneToOne(cascade= CascadeType.ALL)
    @JoinColumn(
            name="nomManager",
            referencedColumnName = "nomManager",
            unique=true,
            foreignKey = @ForeignKey(name = "FK_ETM_MGR"))
    private Manager manager;    
    
    // ==================Cree la relació amb la classe ePlayer===================
    @OneToMany(mappedBy="team",
            cascade=CascadeType.PERSIST,
            fetch = FetchType.LAZY)
    private Set<ePlayer> elsJugadors = new HashSet<ePlayer>(); 
    
    
    // ==================Cree la relació amb la classe Compite===================
    @OneToMany(mappedBy = "team")
    private Set<Compite> team = new HashSet<>();
    
    
    
    // Afegim un jugador al equip.
    public void afigJugador(ePlayer player){
        if (!this.elsJugadors.contains(player)){
            this.elsJugadors.add(player);
            player.afigEquip(this);
        }
    }
    
    // Afegim una competició.
    public void afigCompeticio(Compite compite){
        team.add(compite);
    }
    
    // Constructor
    public eTeam(String nomTeam, int pressupost){
        this.nomTeam = nomTeam;
        this.pressupost = pressupost;
        
    }
    
    public String mostraJugadors(){
        String res="";
        if (this.elsJugadors.isEmpty()){
            res = "";
        }else{
            res += "· Jugadors:\n\t\t";
            for (ePlayer jug : elsJugadors) {
                res+=jug.toString()+"\n\t\t";
            }
        }
        return res;
    }
    
    @Override
    public String toString(){
        return "· " + nomTeam + " amb " + this.manager.getNomManager() + " de manager."; 
    }
    
}
