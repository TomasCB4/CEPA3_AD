package Model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Embeddable;

@Embeddable
public class TeamGamesId implements Serializable {
    
    static final Long serialVersionUID=17L;
    
    private String idTeam;
    private int idGame;

    public void setIdTeam(String idTeam) {
        this.idTeam = idTeam;
    }

    public void setIdGame(int idGame) {
        this.idGame = idGame;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.idTeam);
        hash = 67 * hash + this.idGame;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TeamGamesId other = (TeamGamesId) obj;
        if (this.idGame != other.idGame) {
            return false;
        }
        return Objects.equals(this.idTeam, other.idTeam);
    }

    public String getIdTeam() {
        return idTeam;
    }

    public int getIdGame() {
        return idGame;
    }

    public TeamGamesId(String idTeam, int idGame) {
        this.idTeam = idTeam;
        this.idGame = idGame;
    }

    public TeamGamesId() {
    }
}
