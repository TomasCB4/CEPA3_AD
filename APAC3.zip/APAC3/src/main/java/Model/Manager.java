package Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="manager")
@Setter@Getter@ToString@NoArgsConstructor
public class Manager {
    
    static final Long serialVersionUID=17L;
    
    @Id
    @Column
    private String nomManager;
    
    @Column
    private String dni;
    
    
    @OneToOne(mappedBy="manager")
    private eTeam team;
    
    @Override
    public String toString(){
        
        return "- " + nomManager + " es manager del equip " + team.getNomTeam();        
    }
    
    public Manager(String nomManager, String dni){
        this.nomManager = nomManager;
        this.dni = dni;

    }
}
