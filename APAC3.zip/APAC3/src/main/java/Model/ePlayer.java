package Model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="ePlayer")
@Setter@Getter@ToString@NoArgsConstructor
public class ePlayer {
    
    static final Long serialVersionUID=17L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idPlayer;
    
    @Column
    private String alias;
    
    @Column
    private int age;
    
    @Column
    private String rol;
    
    @Column
    private String nacionalitat;
    
    
    // ===============Relació amb la classe eTeam===============
    @ManyToOne(cascade=CascadeType.PERSIST)
    @JoinColumn(name="team",
            foreignKey = @ForeignKey(name = "FK_PLY_TM" ))
    private eTeam team;
    
    // Constructor
    public ePlayer(String alias, int age, String rol, String nacionalitat) {
        this.alias = alias;
        this.age = age;
        this.rol = rol;
        this.nacionalitat = nacionalitat;
    }   
    
    @Override
    public String toString(){
        return "- " + this.idPlayer + " (" + this.alias + ") juga de " + this.rol + " amb nacionalitat " + this.nacionalitat;
    }
    
    public void afigEquip(eTeam t){
        this.team = t;
        t.afigJugador(this);
    }
}
