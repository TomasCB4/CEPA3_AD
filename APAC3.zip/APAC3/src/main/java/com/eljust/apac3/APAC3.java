package com.eljust.apac3;

import Model.Compite;
import Model.Manager;
import Model.eGames;
import Model.ePlayer;
import Model.eTeam;
import static Teclat.Teclat.lligInt;
import static Teclat.Teclat.lligString;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.query.Query;

/**
 *
 * @author tomas
 */
public class APAC3 {

    public static void select() {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.WARNING); //or whatever level you need

        Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession();
        laSesion.getTransaction().begin();

        System.out.println("======Select de la Taula eTeam======");

        String exit = "";
        do {
            System.out.println("Opcions:\n\t"
                    + "1 - Mostrar tots\n\t"
                    + "2 - Mostrar un equip per el nom\n\t"
                    + "3 - Eixir");

            int seleccio = lligInt("Quina opció vols fer: ", 1, 3);
            switch (seleccio) {
                case 1:
                    Query<eTeam> q = laSesion.createQuery("from eTeam");

                    List<eTeam> elsEquips = q.list();

                    for (eTeam equip : elsEquips) {
                        System.out.println(equip);
                        System.out.println("\t" + equip.mostraJugadors());
                    }
                    break;

                case 2:

                    Query<eTeam> q2 = laSesion.createQuery("select a from eTeam a where a.nomTeam = ?1");

                    String nom = lligString("Dis-me el nom del equip a mostrar: ");

                    q2.setParameter(1, nom);

                    eTeam team = (eTeam) q2.uniqueResult();

                    System.out.println(team.toString());
                    System.out.println("\t" + team.mostraJugadors());

                    break;
                case 3:
                    exit = "quit";

            }

        } while (!exit.equals("quit"));

        //close all
        laSesion.getTransaction().commit();
        laSesion.close();
    }

    public static void insert() {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.WARNING); //or whatever level you need

        Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession();
        laSesion.getTransaction().begin();

        System.out.println("=====Insert de un eTeam=====");

        eTeam team = new eTeam(); // Cree el eTeam

        String nomTeam = lligString("Dis-me el nom del equip: ");
        team.setNomTeam(nomTeam); // Afegim el nom al equip.

        int pres = lligInt("Dis-me el pressupost del equip: ");
        team.setPressupost(pres); // Afegim el pressupost.

        System.out.println("\n=====Insert del manager del eTeam=====");
        Manager m = creaManager();

        m.setTeam(team); // Afig el team al manager.
        team.setManager(m); // Afegixc en el team un manager.

        laSesion.persist(team); // Guardem en la BBDD.

        System.out.println(team); // Mostrem el team

        laSesion.getTransaction().commit();
        laSesion.close();
    }

    public static void update() {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.WARNING); //or whatever level you need

        Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession();
        laSesion.getTransaction().begin();

        System.out.println("=====Update de un eTeam=====");

        String equip = lligString("Dis-me el equip a modificar: ");

        eTeam team = laSesion.get(eTeam.class, equip); // Carreguem el equip.

        String exit = "";
        do {
            System.out.println("Opcions:\n\t"
                    + "1 - Modificar pressupost\n\t"
                    + "2 - Modificar Manager\n\t"
                    + "3 - Eixir");

            int seleccio = lligInt("Queopció vols fer: ", 1, 4);

            switch (seleccio) {
                case 1:
                    
                    System.out.println("======Modificant el pressupost del equip " + team.getNomTeam() + "======");
                    
                    int pressupost = lligInt("Dis-me el nou pressupost del equip: ");
                    
                    team.setPressupost(pressupost);                    
                    laSesion.update(team); // Actualitzem el equip
                    
                    System.out.println(team.toString());
                    break;
                
                case 2:
                    
                    System.out.println("======Modificant el manager del equip " + team.getNomTeam() + "======");
                    
                    Manager m = creaManager();
                    
                    team.setManager(m);
                    laSesion.update(team);
                    
                    System.out.println(team.toString());
                    break;
                
                case 3:
                    exit = "quit";
                    break;

            }
        } while (!exit.equals("quit"));

        laSesion.getTransaction().commit();
        laSesion.close();
    }
    
    public static void delete(){
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.WARNING); //or whatever level you need

        Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession();
        laSesion.getTransaction().begin();
        
        System.out.println("=====Delete de un eTeam=====");
        
        String equip = lligString("Dis-me el equip a modificar: ");

        eTeam team = laSesion.get(eTeam.class, equip); // Carreguem el equip.
        laSesion.delete(team);
        
        System.out.println("El equip " + team.getNomTeam() + " ha sigut borrat.");
        
        laSesion.getTransaction().commit();
        laSesion.close();
    }
    
    public static Manager creaManager(){
        Manager m = new Manager();
        String nomManager = lligString("Dis-me el nom del manager: ");
        m.setNomManager(nomManager); // Afegixc el nom del manager.

        String dniManager = lligString("Dis-me el dni del manager: ");
        m.setDni(dniManager); // Afixc el dni del manager.
        return m;
    }

    public static void main(String[] args) {

        String exit = "";
        do {

            System.out.println("==========CRUD de la BBDD de eSports==========");

            // Sobre la taula eTeam (per el moment)
            System.out.println("Opcions:\n\t"
                    + "1 - Select\n\t"
                    + "2 - Insert\n\t"
                    + "3 - Update\n\t"
                    + "4 - Delete\n\t"
                    + "5 - Eixir");

            int seleccio = lligInt("Quina opció vols fer: ", 1, 5);

            switch (seleccio) {
                case 1:
                    select();
                    break;

                case 2:
                    insert();
                    break;

                case 3:
                    update();
                    break;
                
                case 4:
                    delete();
                    break;
                    
                case 5:
                    exit = "quit";
                    break;
            }

        } while (!exit.equals("quit"));

        
        // ======================PRIMERES PROVES DE LA BBDD======================
//        // Cee un manager.
//        Manager m1 = new Manager("Tomas", "10010010E");
//        
//        // Cree jugadors (String alias, int age, String rol, String nacionalitat)
//        ePlayer p1 = new ePlayer("Faker", 24, "mid", "Koreano");
//        ePlayer p2 = new ePlayer("Rekkles", 26, "adc", "Sueco");
//        
//        
//        // Cree un eTeam
//        eTeam t1 = new eTeam("Eretics", 120000);
//        t1.setManager(m1); // L'hi afegixc al team un manager.
//        m1.setTeam(t1); // L'hi afegixc al manager el eTeam.
//        
//        p1.afigEquip(t1);
//        p2.afigEquip(t1);
//        
//        System.out.println(t1.toString() + "\n\t" + t1.mostraJugadors());
//        
//        laSesion.persist(t1); // Guardem en la BBDD.
//
//         System.out.println(t1.toString() + "\n\t" + t1.mostraJugadors());
//        // Carregue el eTeam guardat en la BBDD.
//        eTeam t1 = laSesion.get(eTeam.class, "Eretics");        
//        System.out.println(t1 + t1.mostraJugadors());
//        
//        eGames g1 = new eGames("League of Legends", "MOBA");
//        laSesion.persist(g1); // Guardem el eGame
//        
//        Compite competi = new Compite(); // Cree la competi
//        competi.setGame(g1); // Afegixc el videojoc.
//        competi.setTeam(t1); // Afegixc el equip.
//        competi.setNJugadores(5); // Afegixc el número de jugadors.
//        
//        g1.afigCompeticio(competi); // Afegixc la competició en el HashSet del videojoc.
//        t1.afigCompeticio(competi); // Afegixc la competició en el HashSet del equip.
//        
//        laSesion.persist(competi); // Guarde la competi
//        
//        System.out.println(competi.toString());
    }
}
